package com.danaid.danaidapp.model.entities

import com.google.firebase.firestore.FieldValue
import java.util.*
import kotlin.collections.ArrayList

data class User(
     val phoneList: ArrayList<Phone> = ArrayList<Phone>(),
     val fullName: String,
     val profil: String,
     val emailAdress: String?,
     val imageUrl: String?,
     val createdDate: Date,
     val urlCNI:String,
     val isEnabled:Boolean
)
{
     constructor():this(ArrayList<Phone>(),"","","","",Date(),"",false)
}