package com.danaid.danaidmobile.allUi.adherentView.items

import android.content.Context
import com.danaid.danaidapp.model.entities.MembreFamille
import com.xwray.groupie.kotlinandroidextensions.Item
import com.xwray.groupie.kotlinandroidextensions.ViewHolder

class FamilleMemberItem(
    val membreFamille: MembreFamille,
    val context: Context
) : Item() {
    override fun getLayout(): Int {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun bind(viewHolder: ViewHolder, position: Int) {

      /*  viewHolder.itemView.id_edit_nom_membre.text = membreFamille.nomComplet
        viewHolder.itemView.id_edit_statut_membre.text = membreFamille.statusMembre
        viewHolder.itemView.id_edit_age_membre.text = membreFamille.dateNaissance.toString()
        viewHolder.itemView.id_edit_sex_membre.text = membreFamille.genre
        viewHolder.itemView.btn_voir_detail_profil.setOnClickListener {


            if(membreFamille.phoneList.get(0).number == FirebaseAuth.getInstance().currentUser!!.phoneNumber){

                context.toast(context.getString(R.string._impossible_ouvrir_carte))

            }else{
                *//*  val action = ListFragmentDirections.actionListFragmentToDetailFragment()
                               action.doUid = membreFamille.UID
                               Navigation.findNavController(it).navigate(action)*//*

                // recherce du membre de la famille ayant ces informations:


                val myProgress =
                    context.indeterminateProgressDialog(context.getString(R.string._text_chargement_en_cours))
                FireStoreAdherentUtils.findFamilleMemberUid(
                    membreFamille,
                    onSucces = { familleMember, Uid ->

                        //TODO: Passer plutot d'adherent recuperer en paramettre et non son UID
                        myProgress.dismiss()
                        //DetailFamillMemberFragment.curetFamilleMemberUid = Uid
                        DetailFamillMemberFragment.newfamileMember = familleMember

                        try {
                            Navigation.findNavController(it)
                                .navigate(R.id.action_maFamilleFragment_to_detailFamillMemberFragment)
                        } catch (ex: Exception) {

                        }


                    },
                    onError = {
                        context.toast(context.getString(R.string._text_erreur_recup_info))
                    })
            }

        }

        if (membreFamille.genre == "Masculin") {
            GlideApp.with(context)
                .load(R.drawable.icon_male)
                .into(viewHolder.itemView.imageView_profilemembre_famille_sex)
        } else {
            GlideApp.with(context)
                .load(R.drawable.icon_female)
                .into(viewHolder.itemView.imageView_profilemembre_famille_sex)
        }

        if (!membreFamille.isEnabled)
            viewHolder.itemView.id_famille_memb_view_status.setBackgroundColor(Color.WHITE)


        GlideApp.with(context)
            .load(membreFamille.urlImage)
            .transform(CircleCrop())
            .into(viewHolder.itemView.imageView_profilemembre_famille)*/
    }

    //override fun getLayout() : Int= R.layout.row_item_famille_member
}