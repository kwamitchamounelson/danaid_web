package com.danaid.danaidmobile.allUi.authentification.uiFragments.creerSponsor

import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.danaid.danaidmobile.R

class CreateSponsorAcountFragment : Fragment() {

    companion object {
        fun newInstance() = CreateSponsorAcountFragment()
    }

    private lateinit var viewModel: CreateSponsorAcountViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.create_sponsor_acount_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(CreateSponsorAcountViewModel::class.java)
        // TODO: Use the ViewModel
    }

}
