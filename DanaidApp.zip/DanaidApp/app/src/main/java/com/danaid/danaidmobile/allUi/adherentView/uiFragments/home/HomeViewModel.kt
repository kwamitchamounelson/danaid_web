package com.danaid.danaidmobile.allUi.adherentView.uiFragments.home

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.danaid.danaidapp.model.entities.Adherent
import com.danaid.danaidmobile.repositories.gestionAdherents.FireStoreAdherentUtils

class HomeViewModel : ViewModel() {

    private val TAG = "HomeViewModel"

    val adherentObserver = MutableLiveData<Adherent>()
    lateinit var curendAdherent: Adherent

    fun findCurentAdherentInfos() {
        FireStoreAdherentUtils.getCurentAdherentFromFiresTore(onSucess = { findingCurentAdherent ->
            curendAdherent = findingCurentAdherent
            adherentObserver.value = curendAdherent
            Log.d(TAG, "current Adherent is ${curendAdherent.createdDate}")

        }, onError = {
            Log.d(TAG, "Error to geting Adherent informations")
        })
    }


}