package com.danaid.danaidmobile.allUi.authentification.uiFragments.selectionProfil.item

import androidx.navigation.Navigation
import com.bumptech.glide.Glide
import com.danaid.danaidmobile.R
import com.danaid.danaidmobile.allUi.authentification.entities.ENUMPROFIL
import com.danaid.danaidmobile.allUi.authentification.entities.Profil
import com.xwray.groupie.kotlinandroidextensions.Item
import com.xwray.groupie.kotlinandroidextensions.ViewHolder
import kotlinx.android.synthetic.main.row_item_profil.view.*

class ProfilItem(val profil: Profil) : Item() {
    override fun bind(viewHolder: ViewHolder, position: Int) {
        viewHolder.itemView.id_profil_name.text = profil.name
        viewHolder.itemView.id_profil_descrition.text = profil.description

        Glide.with(viewHolder.itemView)
            .load(profil.image)
            .error(R.drawable.ic_person_black_24dp)
            .into(viewHolder.itemView.id_profil_image)

        viewHolder.itemView.setOnClickListener {
            var ressource = R.id.action_selectionProfilFragment_to_createAdherentAcountFragment
            when(profil){
                ENUMPROFIL.ADHERENT.profil ->{
                    ressource = R.id.action_selectionProfilFragment_to_createAdherentAcountFragment
                }
                ENUMPROFIL.SPONSOR.profil ->{
                    ressource = R.id.action_selectionProfilFragment_to_createSponsorAcountFragment
                }
                ENUMPROFIL.MEDECIN.profil ->{
                    ressource = R.id.action_selectionProfilFragment_to_createMedecintAcountFragment
                }
                ENUMPROFIL.PRESTATAIRE.profil ->{
                    ressource = R.id.action_selectionProfilFragment_to_createPrestatireFragment
                }
            }
            Navigation.findNavController(it)
                .navigate(ressource)
        }
    }

    override fun getLayout() = R.layout.row_item_profil

}