package com.danaid.danaidmobile.allUi.authentification.uiFragments.creerCompteAdherent

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CircleCrop
import com.danaid.danaidapp.general_util.*
import com.danaid.danaidapp.model.entities.repositories.remote.FireStoreUsersutils
import com.danaid.danaidmobile.R
import com.danaid.danaidmobile.allUi.authentification.entities.NiveauDService
import com.danaid.danaidmobile.repositories.gestionAdherents.FireStoreAdherentUtils
import com.google.android.material.snackbar.Snackbar
import com.xwray.groupie.Section
import kotlinx.android.synthetic.main.alert_dialog_infor_mation_nv_services.view.*
import kotlinx.android.synthetic.main.create_adherent_acount_fragment.*
import kotlinx.android.synthetic.main.dialog_select_image.view.*
import kotlinx.android.synthetic.main.view_niveau_service1.*
import kotlinx.android.synthetic.main.view_niveau_service3.*
import kotlinx.android.synthetic.main.view_niveau_service_2.*
import org.jetbrains.anko.alert
import org.jetbrains.anko.indeterminateProgressDialog
import org.jetbrains.anko.longToast
import org.jetbrains.anko.toast
import java.io.ByteArrayOutputStream
import java.util.*


class CreateAdherentAcountFragment : Fragment() {

    companion object {
        fun newInstance() = CreateAdherentAcountFragment()
    }

    private lateinit var viewModel: CreateAdherentAcountViewModel
    private val TAG = "CreateAdherentAc"

    private var shouldInitrecycleViewModules = true
    private lateinit var moduleSection: Section

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        (activity as AppCompatActivity).supportActionBar!!.apply {
            title = getString(R.string.title_adherentcreer_compte_adherent)
        }
        return inflater.inflate(R.layout.create_adherent_acount_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(CreateAdherentAcountViewModel::class.java)
        viewModel.initNiveauSeerciesOfView()
        configureNiveauxService()
/*        try {
            id_createad_herent_rv_service_level.apply {
                layoutManager = LinearLayoutManager(
                    this@CreateAdherentAcountFragment.context,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )

                adapter = GroupAdapter<ViewHolder>().apply {
                    moduleSection = Section(viewModel.listOfNiveauService)
                    add(moduleSection)

                    setOnItemClickListener(onItemClick)
                }
            }
            shouldInitrecycleViewModules = false
        } catch (e: Exception) {
            Log.e(TAG, "Erreur :" + e.message)
        }*/

        configureOnclickListener()
    }

    private fun configureNiveauxService() {

        _id_view_niveau_service1.setOnClickListener {

            viewModel.niveauProtection = 1

            id_imv_niveau_service1_is_selected.visibility = View.VISIBLE
            id_imv_niveau_service2_is_selected.visibility = View.GONE
            id_imv_niveau_service3_is_selected.visibility = View.GONE
            val dialogView =
                LayoutInflater.from(context!!)
                    .inflate(
                        R.layout.alert_dialog_infor_mation_nv_services,
                        (view!!.parent) as ViewGroup,
                        false
                    )
            val builder = AlertDialog.Builder(context!!)
            dialogView.id_titre_alert_inscription_adherent.text =
                getString(R.string.titre_nv_service1)
            dialogView.id_alert_tv_suivi.text = getString(R.string.suivi_nv_service1)
            dialogView.id_alert_tv_couverture.text = getString(R.string.pourcentage_nv_service_1)
            dialogView.id_alert_tv_plafond_annuel.text =
                getString(R.string.plafond_anuelle_nv_service1)
            dialogView.id_alert_tv_frais_inscription.text =
                getString(R.string.frais_inscription_nv_service1)
            dialogView.id_alert_tv_cotisation.text = getString(R.string.cotisation_nv_service1)
            dialogView.id_alert_tv_paiement.text = getString(R.string.paiement_nv_service1)

            builder.setView(dialogView)
            val alertDialog = builder.create()
            alertDialog.show()
            dialogView.id_alert_nv_acces_ok.setOnClickListener {
                alertDialog.dismiss()
            }
        }
        _id_view_niveau_service2.setOnClickListener {

            viewModel.niveauProtection = 2
            id_imv_niveau_service2_is_selected.visibility = View.VISIBLE
            id_imv_niveau_service1_is_selected.visibility = View.GONE
            id_imv_niveau_service3_is_selected.visibility = View.GONE
            val dialogView =
                LayoutInflater.from(context!!)
                    .inflate(
                        R.layout.alert_dialog_infor_mation_nv_services,
                        (view!!.parent) as ViewGroup,
                        false
                    )
            val builder = AlertDialog.Builder(context!!)
            dialogView.id_titre_alert_inscription_adherent.text =
                getString(R.string.titre_nv_service2)
            dialogView.id_alert_tv_suivi.text = getString(R.string.suivi_nv_service2)
            dialogView.id_alert_tv_couverture.text = getString(R.string.pourcentage_nv_service_2)
            dialogView.id_alert_tv_plafond_annuel.text =
                getString(R.string.plafond_anuelle_nv_service2)
            dialogView.id_alert_tv_frais_inscription.text =
                getString(R.string.frais_inscription_nv_service2)
            dialogView.id_alert_tv_cotisation.text = getString(R.string.cotisation_nv_service2)
            dialogView.id_alert_tv_paiement.text = getString(R.string.paiement_nv_service2)

            builder.setView(dialogView)
            val alertDialog = builder.create()
            alertDialog.show()
            dialogView.id_alert_nv_acces_ok.setOnClickListener {
                alertDialog.dismiss()
            }
        }
        _id_view_niveau_service3.setOnClickListener {
            viewModel.niveauProtection = 3

            id_imv_niveau_service3_is_selected.visibility = View.VISIBLE
            id_imv_niveau_service1_is_selected.visibility = View.GONE
            id_imv_niveau_service2_is_selected.visibility = View.GONE
            val dialogView =
                LayoutInflater.from(context!!)
                    .inflate(
                        R.layout.alert_dialog_infor_mation_nv_services,
                        (view!!.parent) as ViewGroup,
                        false
                    )
            val builder = AlertDialog.Builder(context!!)
            dialogView.id_titre_alert_inscription_adherent.text =
                getString(R.string.titre_nv_service3)
            dialogView.id_alert_tv_suivi.text = getString(R.string.suivi_nv_service3)
            dialogView.id_alert_tv_couverture.text = getString(R.string.pourcentage_nv_service_3)
            dialogView.id_alert_tv_plafond_annuel.text =
                getString(R.string.plafond_anuelle_nv_service3)
            dialogView.id_alert_tv_frais_inscription.text =
                getString(R.string.frais_inscription_nv_service3)
            dialogView.id_alert_tv_cotisation.text = getString(R.string.cotisation_nv_service3)
            dialogView.id_alert_tv_paiement.text = getString(R.string.paiement_nv_service3)

            builder.setView(dialogView)
            val alertDialog = builder.create()
            alertDialog.show()
            dialogView.id_alert_nv_acces_ok.setOnClickListener {
                alertDialog.dismiss()
            }
        }
    }

    private fun configureOnclickListener() {
        id_btn_envoyer_info_adherent.setOnClickListener {
            if (controlerDonnees()) {

                context!!.alert {
                    title = getString(R.string.titre_contract)
                    message = getString(R.string.contenu_contrat_numerique)
                    positiveButton(getString(R.string._text_accepter_contract)) {
                        saveAdherentData()
                    }
                    negativeButton(getString(R.string._text_refuser_contract)) {
                        Snackbar.make(
                            _adherent_create_profil,
                            getString(R.string._text_snackbar_infor_accepter_contract),
                            Snackbar.LENGTH_LONG
                        ).show()
                    }
                }.show()

            } else {
                Snackbar.make(
                    _adherent_create_profil,
                    getString(R.string._text_snackbar_infor_bien_remplir_ls_champ),
                    Snackbar.LENGTH_LONG
                ).show()
            }
        }

        id_profil_adherent_date_naissance.setOnClickListener {
            val c = Calendar.getInstance()
            val year = 1985
            val month = 0
            val day = 1
            val dpd = DatePickerDialog(
                context!!,
                DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
                    // Display Selected date in TextView
                    val date = "$dayOfMonth/${monthOfYear + 1}/$year"
                    id_profil_adherent_date_naissance.text = date
                    viewModel.dateNaissanceAdherent = Date(year, monthOfYear, dayOfMonth)
                },
                year,
                month,
                day
            )
            dpd.show()
        }

        id_create_adherent_iv_select_image.setOnClickListener {
            val dialogView =
                LayoutInflater.from(context!!)
                    .inflate(R.layout.dialog_select_image, (view!!.parent) as ViewGroup, false)

            val builder = AlertDialog.Builder(context!!)
            //dialogView.textview_info_dialog.text = text
            builder.setView(dialogView)

            val alertDialog = builder.create()
            alertDialog.show()

            dialogView.id_btn_camera.setOnClickListener {
                alertDialog.dismiss()
                permissionToOpenCamera()


            }
            dialogView.id_btn_galerie.setOnClickListener {
                alertDialog.dismiss()
                permissionopenGallerie()
            }
        }

    }

    private fun permissionToOpenCamera() {
        if (ActivityCompat.checkSelfPermission(
                context!!,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {

            ActivityCompat.requestPermissions(
                context as Activity,
                arrayOf(Manifest.permission.CAMERA),
                REQUESTOPENCAMERA
            )
        } else {
            if (ActivityCompat.checkSelfPermission(
                    context!!,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED
            ) {

                ActivityCompat.requestPermissions(
                    context as Activity,
                    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA),
                    REQUESTrEADiMAGE
                )
            } else {
                openCamera()
            }
        }
    }

    private fun openCamera() {
        val values = ContentValues()
        values.put(MediaStore.Images.Media.TITLE, "New Picture")
        values.put(MediaStore.Images.Media.DESCRIPTION, "From the Camera")
        viewModel.selectedImagePathUri =
            context!!.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        //camera intent
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, viewModel.selectedImagePathUri)
        startActivityForResult(cameraIntent, IMAGE_CAPTURE_CODE)
    }

    private fun openGallerie() {
        val intent = Intent().apply {
            type = "image/*"
            action = Intent.ACTION_GET_CONTENT
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/jpeg", "image/png"))
        }
        startActivityForResult(
            Intent.createChooser(intent, "Selectionnez une image"),
            RC_SELECT_IMAGE
        )
    }

    private fun permissionopenGallerie() {
        if (ActivityCompat.checkSelfPermission(
                context!!,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {

            ActivityCompat.requestPermissions(
                context as Activity,
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                REQUESTrEADiMAGE
            )
        } else {
            openGallerie()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            PERMISSION_REQUEST_CODE_PHOTO -> {
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                ) {
                    openCamera()
                } else {
                    context!!.longToast("Permission Denied")
                }
                return
            }
            REQUESTrEADiMAGE -> {
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                ) {
                    openGallerie()
                } else {
                    context!!.longToast("Permission Denied")
                }
                return
            }
            else -> {

            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_SELECT_IMAGE && resultCode == Activity.RESULT_OK &&
            data != null && data.data != null
        ) {
            viewModel.selectedImagePathUri = data.data!!
            val selectedImageBmp =
                MediaStore.Images.Media.getBitmap(
                    context!!.contentResolver,
                    viewModel.selectedImagePathUri
                )
            val outPutStream = ByteArrayOutputStream()
            selectedImageBmp.compress(Bitmap.CompressFormat.JPEG, 90, outPutStream)
            //selectedImageBytes = outPutStream.toByteArray()

            //imageView_profile_picture_adherent.loaImage(selectedImagePathUri,getProgressDrawable(imageView_profile_picture_adherent.context))
            Glide.with(id_create_adherent_iv_profil.context)
                .load(viewModel.selectedImagePathUri)
                .transform(CircleCrop())
                .into(id_create_adherent_iv_profil)

        } else if (requestCode == IMAGE_CAPTURE_CODE && resultCode == Activity.RESULT_OK) {
            Glide.with(id_create_adherent_iv_profil.context)
                .load(viewModel.selectedImagePathUri)
                .transform(CircleCrop())
                .into(id_create_adherent_iv_profil)

        }
    }

    private fun saveAdherentData() {
        if (isUriImageNotEmpty()) {
            val dialogImage =
                context!!.indeterminateProgressDialog(getString(R.string.enregistrement_encours))

            StorageUtil.uploadFromLocalFile(
                viewModel.selectedImagePathUri!!,
                StorageUtil.IMAGE_ADHERENTS_STORAGE_REF,
                onSuccess = { imageurl ->
                    dialogImage.dismiss()
                    viewModel.imageUrl = imageurl
                    saveAdherentInformation()
                })
        } else {
            saveAdherentInformation()
        }
    }

    private fun saveAdherentInformation() {
        viewModel.createAdherent()
        FireStoreUsersutils.saveUserToFireStore(viewModel.user, onComplete = { isSucces ->
            if (isSucces) {
                FireStoreAdherentUtils.saveAdherentToFireStore(
                    viewModel.adherent,
                    onComplete = { isSuccess2 ->
                        if (isSuccess2) {
                            opendPaiementFragment()
                            Log.d(TAG, "Adhérent creer avec succes")
                        } else {
                            Snackbar.make(
                                _adherent_create_profil,
                                getString(R.string._text_erreur_enregistrement_informations),
                                Snackbar.LENGTH_LONG
                            ).show()
                        }
                    })

            } else {
                context!!.toast(getString(R.string.text_erreur_enregistrement_user))
            }
        })
    }

    fun opendPaiementFragment() {
       // niveau_de_protection

        val action = CreateAdherentAcountFragmentDirections.actionCreateAdherentAcountFragmentToPaiementInscriptionFragment()
        action.niveauDeProtection = viewModel.niveauProtection
        Navigation.findNavController(_adherent_create_profil)
            .navigate(action)
    }

/*    private val onItemClick = OnItemClickListener { item, view ->

        //initNiveauSeerciesOfView()
        if (item is NiveauServiceItem) {
            val index = viewModel.listOfNiveauService.indexOf(item)
            val newItem = viewModel.listOfNiveauService[index] as NiveauServiceItem
            newItem.niveauService.isSelected = true
            viewModel.listOfNiveauService[index] = newItem
            // item.niveauService.isSelected = true

            *//*         if (item.niveauService.isSelected) {
                          item.niveauService.isSelected = false
                          view.id_imv_niveau_service_is_selected.visibility = View.GONE
                      } else {
                          item.niveauService.isSelected = true
                          view.id_imv_niveau_service_is_selected.visibility = View.VISIBLE
                      }*//*

            when (item.niveauService) {
                ENUMNIVEAUSERVICES.NIVEAUSERVICE1.niveauDService -> {
                    //TODO Chargement de l'icon de la categorie de transaction
                }

                ENUMNIVEAUSERVICES.NIVEAUSERVICE2.niveauDService -> {
                    //TODO Chargement de l'icon de la categorie de transaction

                }
                ENUMNIVEAUSERVICES.NIVEAUSERVICE3.niveauDService -> {
                    //TODO Chargement de l'icon de la categorie de transaction

                }
                ENUMNIVEAUSERVICES.NIVEAUSERVICE1.niveauDService -> {
                    //TODO Chargement de l'icon de la categorie de transaction

                }
                else -> {

                }
            }

            val dialogView =
                LayoutInflater.from(context!!)
                    .inflate(
                        R.layout.alert_dialog_avertissement_inscription,
                        (view!!.parent) as ViewGroup,
                        false
                    )

            val builder = AlertDialog.Builder(context!!)

            //dialogView.textview_info_dialog.text = text
            builder.setView(dialogView)

            val alertDialog = builder.create()
            alertDialog.show()

            dialogView.id_alert_nv_acces_ok.setOnClickListener {
                alertDialog.dismiss()

            }
            item.notifyChanged()

        }
    }*/

    private fun controlerDonnees(): Boolean {
        return (ifEmailValid() && ifAgeCorrect() && isNomcorrect() && isCommunecorrect())
    }

    private fun isUriImageNotEmpty(): Boolean {
        return if (viewModel.selectedImagePathUri != null) true else false
    }

    private fun ifEmailValid(): Boolean {
        return if (isEmailValid(id_profil_adherent_email.text.toString())) {
            viewModel.addresseEmail = id_profil_adherent_email.text.toString()
            true
        } else {
            id_profil_adherent_email.error = getString(R.string._text_entrer_email_valid)
            false
        }
    }

    private fun ifAgeCorrect(): Boolean {
        val anneNaissanceEnfant = viewModel.dateNaissanceAdherent.year
        val thisYear = getCurrentdate().year

        if (thisYear - anneNaissanceEnfant < 21) {
            showAlertForAge()
            return false
        } else {
            return true
        }
    }

    private fun isNomcorrect(): Boolean {
        return if (id_profil_adherent_nom_famille.text.toString().isNotEmpty()) {
            val nomComplet =
                id_profil_adherent_nom_famille.text.toString() + id_profil_adherent_prenom.text.toString()
            viewModel.nomCOmplet = nomComplet
            true
        } else {
            id_profil_adherent_nom_famille.error = getString(R.string.nom_requi)
            false
        }
    }

    private fun isCommunecorrect(): Boolean {
        return if (id_profil_adherent_commune.text.toString().isNotEmpty()) {
            viewModel.commune = id_profil_adherent_commune.text.toString()
            true
        } else {
            id_profil_adherent_commune.error = getString(R.string.commune_requise)
            false
        }
    }

    private fun showAlertForAge() {
        context!!.alert {
            title = getString(R.string.titre_age_non_valide)
            message = getString(R.string._text_age_adherent_non_valide)

            positiveButton("OK") {
            }
            /* negativeButton(getString(R.string._text_refuser_contract)) {

             }*/
        }.show()
    }

}
