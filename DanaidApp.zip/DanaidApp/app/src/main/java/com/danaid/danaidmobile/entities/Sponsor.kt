package com.danaid.danaidapp.model.entities

import com.google.firebase.firestore.FieldValue
import java.util.*

data class Sponsor(
    val phoneList: ArrayList<Phone>? = ArrayList<Phone>(),
    val fullName: String,
    val profil: String,
    val emailAdress: String,
    val imageUrl: String?,
    val ageMedecin: Date,
    val urlCNI: String,
    val isAnabled:Boolean,
    val createddate: Date
    ){
    constructor(): this(null,"","","","",Date(),"",false,Date())
}