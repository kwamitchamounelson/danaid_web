package com.danaid.danaidapp.model.entities

import java.util.*
import kotlin.collections.ArrayList

data class MembreFamille(
    var adherentId: String,
    var nomComplet: String,
    var statusMembre: String,
    var dateNaissance: Date?,
    var genre: String,
    var phoneList: ArrayList<Phone> = ArrayList(),
    var IfVivreMemeDemeure: Boolean,
    var infoSupplementaire: String,
    var urlDocOfficiel: String,
    var urlImage: String,
    var isEnabled: Boolean,
    var createdDate: Date
) {
    constructor() : this("", "", "", Date(), "", ArrayList(), false, "", "", "", false, Date(0))
}