package com.danaid.danaidmobile.allUi.authentification.uiFragments.creerCompteAdherent

import android.net.Uri
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.danaid.danaidapp.general_util.isOrangeOperator
import com.danaid.danaidapp.model.entities.Adherent
import com.danaid.danaidapp.model.entities.Phone
import com.danaid.danaidapp.model.entities.User
import com.danaid.danaidmobile.allUi.authentification.entities.ENUMNIVEAUSERVICES
import com.danaid.danaidmobile.allUi.authentification.entities.NiveauDService
import com.danaid.danaidmobile.allUi.authentification.uiFragments.creerCompteAdherent.items.NiveauServiceItem
import com.danaid.danaidmobile.repositories.ADHERENT_CATEGORIE
import com.danaid.danaidmobile.repositories.StringOperateurMTN
import com.danaid.danaidmobile.repositories.StringOperateurOrange
import com.google.firebase.auth.FirebaseAuth
import com.xwray.groupie.kotlinandroidextensions.Item
import java.util.*

class CreateAdherentAcountViewModel : ViewModel() {


    val adherentProfilCreated = MutableLiveData<Boolean>()

    var telephone = FirebaseAuth.getInstance().currentUser?.phoneNumber ?: ""
    var nomCOmplet = ""
    var profil = ADHERENT_CATEGORIE
    var addresseEmail = ""
    var imageUrl = ""
    var niveauProtection = 1
    var dateNaissanceAdherent = Date()
    var profession = ""
    var addresse = ""
    var commune = ""
    var categorieNumbreEnfant = ""
    var statusMatrimonialeMarie = false
    var recevoirPaiementMobile = true
    var operateur = ""
    var nombreEnfant = 0
    var urlDocOficiel = ""

    lateinit var user: User
    lateinit var adherent: Adherent

    var pdfName = ""
    var newuriOfficialDoc: Uri? = null
     var selectedImagePathUri: Uri? = null
    private var niveauServiece: NiveauDService? = null



    val listOfNiveauService = arrayListOf<Item>()

    fun initNiveauSeerciesOfView() {
        listOfNiveauService.clear()
        ENUMNIVEAUSERVICES.values().forEach {
            val curentLevel = NiveauServiceItem(it.niveauDService)
            listOfNiveauService.add(curentLevel)
        }
    }

    fun createAdherent() {
        operateur = if (isOrangeOperator(telephone)) StringOperateurOrange else StringOperateurMTN
        val phoneList = ArrayList<Phone>()
        phoneList.add(Phone(telephone, operateur, recevoirPaiementMobile))

        val timestamp = com.google.firebase.firestore.FieldValue.serverTimestamp()

        user = User(
            phoneList,
            nomCOmplet,
            profil,
            addresseEmail,
            imageUrl,
            Calendar.getInstance().time,
            urlDocOficiel,
            false
        )
        adherent = Adherent(
            phoneList,
            nomCOmplet,
            profil,
            addresseEmail,
            imageUrl,
            niveauProtection,
            profession,
            addresseEmail,
            commune,
            statusMatrimonialeMarie,
            nombreEnfant,
            recevoirPaiementMobile,
            dateNaissanceAdherent,
            Calendar.getInstance().time,
            urlDocOficiel,
            false
        )

    }
}
