package com.danaid.danaidmobile.repositories.gestionAdherents

import android.content.Context
import android.util.Log
import com.danaid.danaidapp.model.entities.Adherent
import com.danaid.danaidapp.model.entities.MembreFamille
import com.danaid.danaidapp.model.entities.Paiement
import com.danaid.danaidapp.model.entities.User
import com.danaid.danaidapp.model.entities.repositories.remote.*
import com.danaid.danaidmobile.repositories.*
import com.danaid.danaidmobile.allUi.adherentView.items.FamilleMemberItem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.xwray.groupie.kotlinandroidextensions.Item

object FireStoreAdherentUtils {
    private val TAG = "FireStoreUsersUtils"
    private val firestoreInstance: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    private val curentAdherentDocRef: DocumentReference
        get() = firestoreInstance.document(
            ADHERENTS_COLLECTION_REF + "/${FirebaseAuth.getInstance().currentUser?.phoneNumber
                ?: throw NullPointerException("Phone number is null..")}"
        )

    fun saveAdherentToFireStore(newAdherent: Adherent, onComplete: (isSaved: Boolean) -> Unit) {
        curentAdherentDocRef.get().addOnSuccessListener { documentSnapshot ->
            // on initialise l'adherent la première fois que s'il n'existe pas encore
            if (!documentSnapshot.exists()) {
                curentAdherentDocRef.set(newAdherent).addOnSuccessListener { onComplete(true) }
            } else {
                // s'il existe déja on ne l'initialise plus
                onComplete(false)
            }
        }.addOnFailureListener {
            Log.d(TAG, it.printStackTrace().toString())
            onComplete(false)
        }
    }

    fun getCurentAdherentFromFiresTore(onSucess: (Adherent) -> Unit, onError: () -> Unit) {
        curentAdherentDocRef.get().addOnSuccessListener {
            onSucess(it.toObject(Adherent::class.java)!!)
        }.addOnFailureListener {
            onError()
        }
    }

    fun getMembreFamilleDetailsFromFiresTore(
        idMembrefaille: String,
        onSucess: (MembreFamille) -> Unit,
        onError: () -> Unit
    ) {
        FirebaseFirestore.getInstance().collection(MEMBRE_FAMILLE_COLLECTION)
            .document(idMembrefaille).get().addOnSuccessListener {
            onSucess(it.toObject(MembreFamille::class.java)!!)
        }.addOnFailureListener {
            onError()
        }
    }

    fun updateAdherentInformation(
        newAdherent: Adherent,
        onSucess: () -> Unit,
        onError: () -> Unit
    ) {
        val user = User(
            newAdherent.phoneList!!,
            newAdherent.fullName,
            PROFIL_ADHERENT,
            newAdherent.emailAdress,
            newAdherent.imageUrl,
            newAdherent.createdDate,
            newAdherent.urlDocOficiel,
            newAdherent.isProfilEnabled
        )

        FireStoreUsersutils.upDateuser(user, onSucess = {
            val adherentFielMap = mutableMapOf<String, Any>()
            adherentFielMap["phoneList"] = newAdherent.phoneList!!
            adherentFielMap["nombreEnfant"] = newAdherent.nombreEnfant!!.toInt()
            adherentFielMap["profession"] = newAdherent.profession
            adherentFielMap["profil"] = newAdherent.profil
            adherentFielMap["profilEnabled"] = newAdherent.isProfilEnabled
            adherentFielMap["protectionLevel"] = newAdherent.protectionLevel
            adherentFielMap["statuMatrimonialMarie"] = newAdherent.statuMatrimonialMarie
            adherentFielMap["urlDocOficiel"] = newAdherent.urlDocOficiel
            adherentFielMap["isRecptionPaiementMobile"] = newAdherent.IsRecptionPaiementMobile
            adherentFielMap["imageUrl"] = newAdherent.imageUrl ?: ""
            adherentFielMap["fullName"] = newAdherent.fullName
            adherentFielMap["emailAdress"] = newAdherent.emailAdress
            adherentFielMap["dateNaissance"] = newAdherent.dateNaissance
            adherentFielMap["createdDate"] = newAdherent.createdDate
            adherentFielMap["commune"] = newAdherent.commune
            adherentFielMap["adresse"] = newAdherent.adresse

            curentAdherentDocRef.update(adherentFielMap).addOnSuccessListener {
                Log.d(TAG, "Adherent updated succesfully")
                onSucess()
            }
                .addOnFailureListener {
                    Log.d(TAG, "Error to updated Adherent" + it.cause)
                    onError()
                }
        }, onError = {
            onError()
        })
    }

    fun updatFamileMemberInformation(
        uidAdherent: String,
        newFamileMember: MembreFamille,
        onSucess: () -> Unit,
        onError: () -> Unit
    ) {


        val familleMemberFielMap = mutableMapOf<String, Any>()
        familleMemberFielMap["adherentId"] = newFamileMember.adherentId
        familleMemberFielMap["createdDate"] = newFamileMember.createdDate
        familleMemberFielMap["dateNaissance"] = newFamileMember.dateNaissance!!
        familleMemberFielMap["enabled"] = newFamileMember.isEnabled
        familleMemberFielMap["genre"] = newFamileMember.genre
        familleMemberFielMap["ifVivreMemeDemeure"] = newFamileMember.IfVivreMemeDemeure
        familleMemberFielMap["infoSupplementaire"] = newFamileMember.infoSupplementaire
        familleMemberFielMap["nomComplet"] = newFamileMember.nomComplet
        familleMemberFielMap["phoneList"] = newFamileMember.phoneList
        familleMemberFielMap["statusMembre"] = newFamileMember.statusMembre
        familleMemberFielMap["urlDocOfficiel"] = newFamileMember.urlDocOfficiel
        familleMemberFielMap["urlImage"] = newFamileMember.urlImage


        firestoreInstance.collection(MEMBRE_FAMILLE_COLLECTION).document(uidAdherent)
            .update(familleMemberFielMap).addOnSuccessListener {
            Log.d(TAG, "Famile member updated succesfully")
            onSucess()
        }
            .addOnFailureListener {
                Log.d(TAG, "Error to updated Famile member" + it.cause)
                onError()
            }
    }

    /***
     * a pour but d'ajouter le paiement de l'utilisateur dans la collection des paiements
     */
    fun savePaiement(paiement: Paiement, onComplete: (paiementId: String) -> Unit) {
        val newPaiementInstance = firestoreInstance.collection(PAIEMENT_COLLECTION).document()
        newPaiementInstance.set(paiement).addOnSuccessListener {
            onComplete(newPaiementInstance.id)
            Log.d(TAG, "NewPaiement Saved id: ${newPaiementInstance.id}")
        }.addOnFailureListener {
            onComplete("")
            Log.d(TAG, "Erreur d'enregistrement due à: ${it.cause}")
        }
    }

    /**
     * A pour but d'enregistrer l'id du paiement dans la reference de l'utilisateur
     * **/
    fun savePaiementUserPaiementIdToUserReference(
        paiementId: String,
        onComplete: (isOk: Boolean) -> Unit
    ) {
        curentAdherentDocRef.collection(PAIEMENT_COLLECTION_USER_REF).document()
            .set(mapOf(FIELD_PAIEMENT_ID to paiementId)).addOnSuccessListener {
                onComplete(true)
            }.addOnFailureListener {
                onComplete(false)
            }
    }

    /***
     * a pour but d'ajouter le membre de la famille de l'utilisateur dans la collection des mebres de familles
     */
    fun saveFamillemembre(membreFamille: MembreFamille, onSucess: () -> Unit, onError: () -> Unit) {
        val newMembrefamillenstance =
            firestoreInstance.collection(MEMBRE_FAMILLE_COLLECTION).document()
        newMembrefamillenstance.set(membreFamille).addOnSuccessListener {
            Log.d(TAG, "new famille membed Saved id: ${newMembrefamillenstance.id}")
            saveFamilleMemberIdToUserReference(newMembrefamillenstance.id, onComplete = {
                if (it)
                    onSucess()
                else
                    onError()
            })

        }.addOnFailureListener {
            onError()
            Log.d(TAG, "Erreur d'enregistrement due à: ${it.cause}")
        }
    }

    /**
     * A pour but d'enregistrer l'id du paiement dans la reference de l'utilisateur
     * **/
    fun saveFamilleMemberIdToUserReference(
        memberId: String,
        onComplete: (isOk: Boolean) -> Unit
    ) {
        curentAdherentDocRef.collection(MEMBRE_FAMILLE_COLLECTION).document()
            .set(mapOf(FIELD_MEMBRE_FAMILLE_ID to memberId)).addOnSuccessListener {
                onComplete(true)
            }.addOnFailureListener {
                onComplete(false)
            }
    }

    /**
     * Cette fonction a pour nut de lister les Adherent
     * **/
    /* fun addSearchAdherentListenerForcreatingGroupe(
         valeurRecherche: String,
         context: Context,
         onListen: (List<Item>) -> Unit
     ): ListenerRegistration {
         return firestoreInstance.collection(ADHERENTS_COLLECTION_REF)
             .addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                 if (firebaseFirestoreException != null) {
                     Log.e("FIRESTORE", "Users listener error?", firebaseFirestoreException)
                     return@addSnapshotListener
                 }

                 val items = mutableListOf<Item>()
                 querySnapshot?.documents?.forEach {
                     if (it["phoneNumber"] != FirebaseAuth.getInstance().currentUser?.phoneNumber) {

                         if (!valeurRecherche.isEmpty()) {
                             if (it["fullName"].toString().toUpperCase().contains(valeurRecherche.toUpperCase())
                                 || it["emailAdress"].toString().toUpperCase().contains(valeurRecherche.toUpperCase())
                                 || it["nombreEnfant"].toString().toUpperCase().contains(valeurRecherche.toUpperCase())
                             ) {
                                 items.add(SimpleuserItem(it.toObject(Adherent::class.java)!!, context))
                                 Log.d("FIRESTOREUTIL", "NOUVELLE VALEURE AJOUTTEE !!!")
                             }
                         } else {
                             items.add(SimpleuserItem(it.toObject(Adherent::class.java)!!, context))
                         }
                     }
                 }
                 onListen(items)
             }
     }

     */

    /**
     * Cette fonction a pour but de lister les membres d'une famille
     * **/
    fun addSearchAdherentFamilleListenerForcreatingGroupe(
        valeurRecherche: String,
        context: Context,
        onListen: (List<Item>) -> Unit
    ): ListenerRegistration {
        return firestoreInstance.collection(MEMBRE_FAMILLE_COLLECTION)
            .addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                if (firebaseFirestoreException != null) {
                    Log.e(TAG, "Users listener error?", firebaseFirestoreException)
                    return@addSnapshotListener
                }

                val items = mutableListOf<Item>()
                // On configure le premier élement des cartes pourque ce soit l'adhérent couran

                getCurentAdherentFromFiresTore(onSucess = {
                    // l'adherent courant est avant tout un membre de sa famille
                    val adherentFamillemember = MembreFamille(
                        FirebaseAuth.getInstance().currentUser?.phoneNumber!!,
                        it.fullName,
                        "PARENT",
                        it.dateNaissance,
                        "",
                        it.phoneList!!,
                        true,
                        "",
                        it.urlDocOficiel,
                        it.imageUrl ?: "",
                        it.isProfilEnabled,
                        it.createdDate
                    )
                    items.add(FamilleMemberItem(adherentFamillemember, context))
                    querySnapshot?.documents?.forEach {
                        if (it["adherentId"] == FirebaseAuth.getInstance().currentUser?.phoneNumber) {

                            if (!valeurRecherche.isEmpty()) {
                                if (it["nomComplet"].toString().toUpperCase().contains(
                                        valeurRecherche.toUpperCase()
                                    )
                                    || it["genre"].toString().toUpperCase().contains(valeurRecherche.toUpperCase())
                                    || it["statusMembre"].toString().toUpperCase().contains(
                                        valeurRecherche.toUpperCase()
                                    )
                                ) {
                                    items.add(
                                        FamilleMemberItem(
                                            it.toObject(MembreFamille::class.java)!!,
                                            context
                                        )
                                    )
                                    Log.d(TAG, "NOUVELLE VALEURE AJOUTTEE !!!")
                                }
                            } else {
                                items.add(
                                    FamilleMemberItem(
                                        it.toObject(MembreFamille::class.java)!!,
                                        context
                                    )
                                )
                            }
                        }
                    }
                    onListen(items)

                }, onError = {
                    querySnapshot?.documents?.forEach {
                        if (it["adherentId"] == FirebaseAuth.getInstance().currentUser?.phoneNumber) {

                            if (!valeurRecherche.isEmpty()) {
                                if (it["nomComplet"].toString().toUpperCase().contains(
                                        valeurRecherche.toUpperCase()
                                    )
                                    || it["genre"].toString().toUpperCase().contains(valeurRecherche.toUpperCase())
                                    || it["statusMembre"].toString().toUpperCase().contains(
                                        valeurRecherche.toUpperCase()
                                    )
                                ) {
                                    items.add(
                                        FamilleMemberItem(
                                            it.toObject(MembreFamille::class.java)!!,
                                            context
                                        )
                                    )
                                    Log.d(TAG, "NOUVELLE VALEURE AJOUTTEE !!!")
                                }
                            } else {
                                items.add(
                                    FamilleMemberItem(
                                        it.toObject(MembreFamille::class.java)!!,
                                        context
                                    )
                                )
                            }
                        }
                    }
                    onListen(items)
                })

            }
    }

    fun findFamilleMemberUid(
        membreFamille: MembreFamille,
        onSucces: (getIngmembreFamille: MembreFamille, uid:String) -> Unit,
        onError: () -> Unit
    ) {
        curentAdherentDocRef.collection(MEMBRE_FAMILLE_COLLECTION)
            .addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                run {
                    if (firebaseFirestoreException != null) {
                        Log.e(TAG, "Users listener error?", firebaseFirestoreException)
                    }
                    querySnapshot?.documents?.forEach {
                        var curentFamillememberUid = it["MEMBRE_FAMILLE_ID"] as String
                        firestoreInstance.collection(MEMBRE_FAMILLE_COLLECTION)
                            .document(curentFamillememberUid).get().addOnSuccessListener {

                            val curentFamilMember = it.toObject(MembreFamille::class.java)
                            if (membreFamille.equals(curentFamilMember)) {
                                Log.d(TAG, "Membre de la famille retrouver!!!"+curentFamilMember)
                                onSucces(curentFamilMember, curentFamillememberUid)
                            }
                        }.addOnFailureListener {
                            Log.d(TAG, "Erreur de recherche du Membre de la famille !!!")
                            onError()
                        }
                    }

                }

            }
    }

    fun removeListener(registration: ListenerRegistration) = registration.remove()

}