package com.danaid.danaidmobile.allUi.authentification.paiement

import android.app.ProgressDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import com.danaid.danaidapp.general_util.DANAID_MTN_PAIEMENT_PHONE_NUMBER
import com.danaid.danaidapp.general_util.addMonthOnDate
import com.danaid.danaidapp.general_util.convertDateToSpecificStringFormat
import com.danaid.danaidmobile.R
import com.danaid.danaidmobile.shared_pref.PrefManager
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.dialog_success_paiement.view.*
import kotlinx.android.synthetic.main.paiement_inscription_fragment.*
import org.jetbrains.anko.alert
import org.jetbrains.anko.noButton
import org.jetbrains.anko.yesButton
import java.util.*

class PaiementInscriptionFragment : Fragment() {

    companion object {
        fun newInstance() = PaiementInscriptionFragment()
    }

    private lateinit var viewModel: PaiementInscriptionViewModel
    private lateinit var processDialog: ProgressDialog

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.paiement_inscription_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(PaiementInscriptionViewModel::class.java)

        processDialog = ProgressDialog(context)

        configIncrementationDecrementation()
        configureObservers()
        configureButtons()
    }

    private fun configIncrementationDecrementation() {
        arguments?.let {
            viewModel.adherentprotectionLevel =
                PaiementInscriptionFragmentArgs.fromBundle(it).niveauDeProtection
        }
        when (viewModel.adherentprotectionLevel) {

            1 -> {
                viewModel.configPaiementMin = 3500
                viewModel.configPaiementMax = 42000
                viewModel.configUnit = 3500
            }
            2 -> {
                viewModel.configPaiementMin = 6500
                viewModel.configPaiementMax = 78000
                viewModel.configUnit = 6500
            }

            3 -> {
                viewModel.configPaiementMin = 9500
                viewModel.configPaiementMax = 42000
                viewModel.configUnit = 114000
            }
        }
        id_tv_icrementer_nb_moi.setOnClickListener {
            if (viewModel.compteurNbreMois < 12)
                viewModel.incrementerNombreDeMois()
        }
        id_tv_decrementer_nb_moi.setOnClickListener {
            if (viewModel.compteurNbreMois > 0)
                viewModel.decrementerNombreMois()
        }

        viewModel.initNombreMois()
    }

    private fun configureObservers() {
        viewModel.montantTotalObserver.observe(this, Observer { montantTotal ->
            id_tv_montant_total.text = "$montantTotal fcfa"

            val dateFin = addMonthOnDate(
                Date(),
                viewModel.compteurNbreMois.toInt()
            )
            val dateFinString = convertDateToSpecificStringFormat(dateFin)
            val textDatefin = "${getString(R.string.text_valide_jusqu_au)} $dateFinString"
            id_tv_date_fin.text = textDatefin
        })

        viewModel.nombreDeMoisObserver.observe(this, Observer { nbMois ->
            val textNbMois = "$nbMois ${getString(R.string.mois)}"
            id_tv_valeur_nb_moi.text = textNbMois
            val montantApayer = viewModel.configUnit * viewModel.compteurNbreMois
            id_tv_montant_a_payer_pour_nb_moi.text = "$montantApayer fcfa"
        })

        viewModel.savepaiementEnCour.observe(this, Observer { isEnregistrementEnCour ->
            isEnregistrementEnCour?.let {
                if (!it) {
                    processDialog.dismiss()
                    showConfirmationDialogForPaiement()
                } else {
                    processDialog.setTitle(R.string.enregistrement_encours)
                    processDialog.show()
                }
            }
        }
        )
    }

    private fun configureButtons() {
        id_paiment_buton_pay_now.setOnClickListener {

            val pref = PrefManager(context)
            if (viewModel.canSavepaiment()) {

                if (!pref.ifFirtsPaiementWillDo) {
                    //sendUssDPaiementCode()
                    //TODO declencher l'action d'envoie du code USSD via le réseau téléphonique
                    viewModel.savePaiement()
                } else {
                    Snackbar.make(
                        fragment_firts_paiement,
                        getString(R.string._text_erreur_paiement_deja_fait),
                        Snackbar.LENGTH_LONG
                    ).show()
                }

            } else {
                Snackbar.make(
                    fragment_firts_paiement,
                    getString(R.string._text_error_save_paiement),
                    Snackbar.LENGTH_LONG
                ).show()
            }
        }

        id_paiment_buton_not_pay.setOnClickListener {
            showAvertissemmentAlert(R.string._text_avertissement_paiement_after, onYesTapped = {
                openAdherentMainActivity(it)
            }, onNoTapped = {

            })


        }
    }

    private fun showConfirmationDialogForPaiement() {
        val dialogView =
            LayoutInflater.from(context!!)
                .inflate(
                    R.layout.dialog_success_paiement,
                    (view!!.parent) as ViewGroup,
                    false
                )

        val builder = AlertDialog.Builder(context!!)
        val text =
            getString(R.string._text_message_completer_paiement) + " " + viewModel.montantTotal + " fcfa " +
                    getString(R.string._text_numero_tel) + " " + DANAID_MTN_PAIEMENT_PHONE_NUMBER + " " +
                    getString(R.string._text_message_paiement_fin)

        dialogView.textview_info_dialog.text = text
        builder.setView(dialogView)
        val alertDialog = builder.create()
        alertDialog.show()

        dialogView.buttonOk.setOnClickListener {
            alertDialog.dismiss()
            val pref = PrefManager(context)
            pref.setFirtsPaiement()

            openAdherentMainActivity(fragment_firts_paiement)
        }
    }

    private fun showAvertissemmentAlert(
        messageResource: Int,
        onYesTapped: () -> Unit,
        onNoTapped: () -> Unit
    ) {
        context!!.alert(messageResource) {
            //1. Creating the alert
            yesButton {
                //2. Handling yes button (This is optional)
                onYesTapped()
            }
            noButton {
                //3. Handling no button (This is optional)
                onNoTapped()
            }
            iconResource = R.drawable.icon_warning
        }.show() //4. Showing the alert
    }

    fun openAdherentMainActivity(view: View) {
        Navigation.findNavController(view)
            .navigate(R.id.action_paiementInscriptionFragment_to_adherentMainActivity)
    }
}
