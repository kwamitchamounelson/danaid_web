package com.danaid.danaidmobile.shared_pref;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefManager {
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context _context;
    // shared pref mode
    int PRIVATE_MODE = 0;
    // Shared preferences file name
    private static final String PREF_NAME = "danaidapp.com";
    private static final String IS_FIRST_TIME_LAUNCH = "IsFirstTimeLaunch";
    private static final String USER_CATEGORIE = "USER_CATEGORIE";
    private static final String ADHERENT_SERVICE_LEVEL = "NIVEAU_DE_SERVICE";
    private static final String PREMIER_PAIEMENT_ADHERENT = "PREMIER_PAIEMENT";


    public PrefManager(Context context) {
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }
    public void setFirstTimeLaunch(boolean isFirstTime) {
        editor.putBoolean(IS_FIRST_TIME_LAUNCH, isFirstTime);
        editor.commit();
    }

    public void setUserCategorie(String categorie){
        editor.putString(USER_CATEGORIE, categorie);
        editor.commit();
    }

    public void setAdherentProtectionLevel(int niveauDeService){
        editor.putInt(ADHERENT_SERVICE_LEVEL, niveauDeService);
        editor.commit();
    }

    public void setFirtsPaiement(){
        editor.putBoolean(PREMIER_PAIEMENT_ADHERENT, true);
        editor.commit();
    }

    public Boolean getIfFirtsPaiementWillDo(){
        return pref.getBoolean(PREMIER_PAIEMENT_ADHERENT, false);

    }

    public int getAdherentProtectionLevel(){
      return pref.getInt(ADHERENT_SERVICE_LEVEL, -1);
    }



    public String getUserCategorie(){
        return pref.getString(USER_CATEGORIE, null);
    }

    public boolean isFirstTimeLaunch() {
        return pref.getBoolean(IS_FIRST_TIME_LAUNCH, true);
    }
}