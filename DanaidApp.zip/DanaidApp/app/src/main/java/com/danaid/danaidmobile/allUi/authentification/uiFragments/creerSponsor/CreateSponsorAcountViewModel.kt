package com.danaid.danaidmobile.allUi.authentification.uiFragments.creerSponsor

import androidx.lifecycle.ViewModel

class CreateSponsorAcountViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
