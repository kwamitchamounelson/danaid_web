package com.danaid.danaidmobile.allUi.adherentView.uiFragments.completerMonProfil

import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.danaid.danaidmobile.R

class CompleterMonProfilFragment : Fragment() {

    companion object {
        fun newInstance() = CompleterMonProfilFragment()
    }

    private lateinit var viewModel: CompleterMonProfilViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.completer_mon_profil_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(CompleterMonProfilViewModel::class.java)
        // TODO: Use the ViewModel
    }

}
