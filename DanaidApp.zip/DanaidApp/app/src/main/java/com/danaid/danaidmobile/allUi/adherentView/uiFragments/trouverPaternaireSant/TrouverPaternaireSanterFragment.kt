package com.danaid.danaidmobile.allUi.adherentView.uiFragments.trouverPaternaireSant

import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.danaid.danaidmobile.R

class TrouverPaternaireSanterFragment : Fragment() {

    companion object {
        fun newInstance() = TrouverPaternaireSanterFragment()
    }

    private lateinit var viewModel: TrouverPaternaireSanterViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.trouver_paternaire_santer_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(TrouverPaternaireSanterViewModel::class.java)
        // TODO: Use the ViewModel
    }

}
