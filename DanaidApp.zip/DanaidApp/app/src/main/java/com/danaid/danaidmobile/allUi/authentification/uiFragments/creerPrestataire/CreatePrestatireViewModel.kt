package com.danaid.danaidmobile.allUi.authentification.uiFragments.creerPrestataire

import androidx.lifecycle.ViewModel

class CreatePrestatireViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
