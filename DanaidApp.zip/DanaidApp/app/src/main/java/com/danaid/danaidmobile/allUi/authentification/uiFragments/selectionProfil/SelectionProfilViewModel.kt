package com.danaid.danaidmobile.allUi.authentification.uiFragments.selectionProfil

import androidx.lifecycle.ViewModel

class SelectionProfilViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
