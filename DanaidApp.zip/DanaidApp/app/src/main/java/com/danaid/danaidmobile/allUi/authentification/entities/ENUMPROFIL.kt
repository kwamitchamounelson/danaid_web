package com.danaid.danaidmobile.allUi.authentification.entities

import com.danaid.danaidmobile.R

enum class ENUMPROFIL(val profil:Profil) {
    ADHERENT(Profil("Adhérent","Créez un compte personnel pour votre famille et vous meme", R.drawable.adherent)),
    SPONSOR(Profil("Sponsor","Individu, association ou entreprise, céez un compte pour couvrir 1 ou plusieurs adhérents",R.drawable.sponsor)),
    MEDECIN(Profil("Médecin","Créez un compte de médecin de famille pour suivre des familles et gérer vos services",R.drawable.medecin)),
    PRESTATAIRE(Profil("Prestataire","Créez un compte pour etre reconnu comme une formation sanitaire affiliée et gérez vos services",R.drawable.partenare))
}