package com.danaid.danaidapp.model.entities

data class Phone(
    var number: String,
    var operator: String,
    var receptionPayement: Boolean
) {
    constructor() : this("", "", false)
}