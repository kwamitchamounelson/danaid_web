package com.danaid.danaidmobile.repositories.gestionSponsors

import com.danaid.danaidapp.model.entities.Sponsor
import com.danaid.danaidmobile.repositories.SPONSORS_COLLECTION_REF
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore

object FireStoreSponsorsUtils {
    private val TAG = "FireStoreSponsorsUtils"
    private val firestoreInstance: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    private val curentSponsorRef: DocumentReference
        get() = firestoreInstance.document(
            SPONSORS_COLLECTION_REF + "/${FirebaseAuth.getInstance().currentUser?.phoneNumber
                ?: throw NullPointerException("Phone number is null..")}"
        )

    fun saveSponsorToFireStore(newSponsor: Sponsor, onComplete: (isSaved: Boolean) -> Unit) {
        curentSponsorRef.get().addOnSuccessListener { documentSnapshot ->

            if (!documentSnapshot.exists()) {
                curentSponsorRef.set(newSponsor).addOnSuccessListener { onComplete(true) }
            } else {
                // s'il existe déja on ne l'initialise plus
                onComplete(false)
            }
        }
    }

    fun getCurentSponsorFromFiresTore(onComplete: (Sponsor) -> Unit) {
        curentSponsorRef.get().addOnSuccessListener {
            onComplete(it.toObject(Sponsor::class.java)!!)
        }
    }

    /**
     * Cette fonction a pour nut de lister les Medecins
     * **/
/*    fun addSearchSponsorListenerForcreating(
        valeurRecherche: String,
        context: Context,
        onListen: (List<Item>) -> Unit
     ): ListenerRegistration {
         return firestoreInstance.collection(SPONSORS_COLLECTION_REF)
             .addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                 if (firebaseFirestoreException != null) {
                     Log.e("FIRESTORE", "Users listener error?", firebaseFirestoreException)
                     return@addSnapshotListener
                 }

                 val items = mutableListOf<Item>()
                 querySnapshot?.documents?.forEach {
                     if (it["phoneNumber"] != FirebaseAuth.getInstance().currentUser?.phoneNumber) {

                         if (!valeurRecherche.isEmpty()) {
                             if (it["fullName"].toString().toUpperCase().contains(valeurRecherche.toUpperCase())
                                 || it["emailAdress"].toString().toUpperCase().contains(valeurRecherche.toUpperCase())
                             ) {
                                 items.add(SimpleuserItem(it.toObject(Sponsor::class.java)!!, context))
                                 Log.d(TAG, "NOUVELLE VALEURE AJOUTTEE !!!")
                             }
                         } else {
                             items.add(SimpleuserItem(it.toObject(Sponsor::class.java)!!, context))
                         }
                     }
                 }
                 onListen(items)
             }
     }*/

}