package com.danaid.danaidmobile.allUi.authentification.entities

import android.os.Parcelable
import com.danaid.danaidmobile.R
import java.io.Serializable

data class NiveauDService(
    val nomNiveau: String,
    val montant: Double,
    val periode: String,
    val couverture: String,
    val icon: Int,
    var isSelected: Boolean
):Serializable {
    constructor() : this(
        "", 0.0, "", "",
        R.drawable.ic_niveau_service1, false
    )
}