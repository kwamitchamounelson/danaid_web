package com.danaid.danaidmobile.allUi.authentification.uiFragments


import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import com.danaid.danaidapp.model.entities.User
import com.danaid.danaidapp.model.entities.repositories.remote.FireStoreUsersutils
import com.danaid.danaidmobile.R
import com.danaid.danaidmobile.allUi.adherentView.AdherentMainActivity
import com.danaid.danaidmobile.repositories.PROFIL_ADHERENT
import com.danaid.danaidmobile.repositories.PROFIL_MEDECIN
import com.danaid.danaidmobile.repositories.PROFIL_SPONSOR
import com.danaid.danaidmobile.shared_pref.PrefManager
import com.firebase.ui.auth.AuthUI
import com.firebase.ui.auth.ErrorCodes
import com.firebase.ui.auth.IdpResponse
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.fragment_login.*
import org.jetbrains.anko.alert
import org.jetbrains.anko.indeterminateProgressDialog
import org.jetbrains.anko.startActivity


/**
 * A simple [Fragment] subclass.
 */
class LoginFragment : Fragment() {
    private val RC_SIGN_IN = 1

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_login, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //FirebaseApp.initializeApp(context!!)
        if (FirebaseAuth.getInstance().currentUser != null) {
            //Navigation.findNavController(id_login_sign_in_button).navigate(R.id.action_loginFragment_to_adherentMainActivity)
            checkIfUserHaveAccount()
        }

        id_login_sign_in_button.setOnClickListener {

            context!!.alert {
                title = getString(R.string.titre_contract)
                message = getString(R.string._avertissement_numero_tel_paiement)

                positiveButton(getString(R.string._text_confirmer)) {
                    startAuthentification()
                }
                negativeButton(getString(R.string._text_refuser)) {
                    Snackbar.make(
                        authentification_page,
                        getString(R.string._text_snackbar_infor_accepter_paiement_numero),
                        Snackbar.LENGTH_LONG
                    ).show()
                }
            }.show()
        }
    }

    override fun onResume() {
        super.onResume()
        (activity as AppCompatActivity).supportActionBar!!.hide()
    }

    override fun onStop() {
        super.onStop()
        (activity as AppCompatActivity).supportActionBar!!.show()
    }

    fun startAuthentification() {
        startActivityForResult(
            AuthUI.getInstance()
                .createSignInIntentBuilder()
                .setAvailableProviders(
                    listOf(AuthUI.IdpConfig.PhoneBuilder().build())
                )
                .setLogo(R.drawable.danaid_logo)
                .setTheme(R.style.AppTheme)
                .build(),
            RC_SIGN_IN
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_SIGN_IN) {
            val response = IdpResponse.fromResultIntent(data)

            if (resultCode == Activity.RESULT_OK) {
                checkIfUserHaveAccount()
            } else if (resultCode == Activity.RESULT_CANCELED) {
                if (response == null) return

                when (response.error?.errorCode) {
                    ErrorCodes.NO_NETWORK -> {
                        Snackbar.make(
                            authentification_page,
                            getString(R.string.snack_bar_erreur_reseau),
                            Snackbar.LENGTH_LONG
                        ).show()

                    }

                    ErrorCodes.UNKNOWN_ERROR -> {
                        Snackbar.make(
                            authentification_page,
                            getString(R.string.snackbar_erreur_inkonu),
                            Snackbar.LENGTH_LONG
                        ).show()

                    }

                }
            }
        }
    }

    private fun checkIfUserHaveAccount() {

        val myProgress = context!!.indeterminateProgressDialog(getString(R.string._progres_message))
        FireStoreUsersutils.getCurentUserFromFiresTore(onSucess = { curentUser ->
            // user have account
            myProgress.dismiss()
            startUserViewProfil(curentUser)
        }, onError = {
            // User don't have account
            myProgress.dismiss()
            startUserRegistration()
            myProgress.dismiss()

        })
    }

    private fun startUserRegistration() {
        Navigation.findNavController(id_login_sign_in_button)
            .navigate(R.id.action_loginFragment_to_selectionProfilFragment)
    }

    private fun startUserViewProfil(curentUser: User) {

        when (curentUser.profil) {
            PROFIL_ADHERENT -> {

                val pref = PrefManager(context)
                if (!pref.ifFirtsPaiementWillDo) {
                    Navigation.findNavController(id_login_sign_in_button)
                        .navigate(R.id.action_loginFragment_to_paiementInscriptionFragment)
                    activity!!.finish()
                } else {
                    context!!.startActivity<AdherentMainActivity>()
                    activity!!.finish()
                }
                //  Navigation.findNavController(id_login_sign_in_button).navigate(R.id.action_loginFragment_to_adherentMainActivity)
                // Navigation.findNavController(account_sign_in)
                //   .navigate(R.id.action_connectionFragment_to_adherentProfilActivity)
            }

            PROFIL_MEDECIN -> {
                //Navigation.findNavController(account_sign_in)
                //  .navigate(R.id.action_connectionFragment_to_doctorMainActivity)
            }

            PROFIL_SPONSOR -> {
                //TODO ouvrir la vue profil du sponsor
            }
            else -> {
                Snackbar.make(
                    authentification_page,
                    getString(R.string.snackbar_erreur_compte_inkonu),
                    Snackbar.LENGTH_LONG
                ).show()

            }
        }
    }
}
