package com.danaid.danaidapp.model.entities

import java.util.*

class Prestataire(
    val phone: String,
    val fullName: String,
    val profil: String,
    val emailAdress: String,
    val imageUrl: String?,
    val categorieService: String,
    val sector: String,
    val commune: String,
    val personneContacter: PersonneContact,
    val isAnabled:Boolean,
    val createdDate:Date

)