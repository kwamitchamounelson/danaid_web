package com.danaid.danaidapp.general_util

import android.net.Uri
import com.google.android.gms.tasks.Continuation
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.UploadTask
import java.util.*

object StorageUtil {

    const val IMAGE_ADHERENTS_STORAGE_REF = "photos/profils_adherents/"
    const val IMAGE_MEMBRE_FAMILLE8ADHERENTS_STORAGE_REF =
        "photos/profils_adherents/membres_famille/"
    const val IMAGE_MEDECINS_STORAGE_REF = "photos/profils_Medecins/"
    const val IMAGE_SPONSORS_STORAGE_REF = "photos/profils_particuliers/"
    const val IMAGE_PARTICULIERS_STORAGE_REF = "photos/profils_sponsors/"
    const val PIECE_IDENTITE_ADHERENT_STORAGE_REF = ""

    const val PDF_MEMBRE_FAMILLE_ADHERENTS_STORAGE_REF =
        "pieces_didentite/piece_adherents/pieces_membres_famille_adherents/"
    const val PDF_ADHERENT_STORAGE_REF = "pieces_didentite/piece_adherents/"
    const val PDF_MEDECIN_STORAGE_REF = "pieces_didentite/pieces_medecins/"
    const val PDF_SPONSOR_STORAGE_REF = "pieces_didentite/pieces_sponsor/"


    val storageRef = FirebaseStorage.getInstance().reference

    /**Permet d'uploader les images dans une reference de firestore**/
    fun uploadFromLocalFile(filePath: Uri, refStorage: String, onSuccess: (String) -> Unit) {
        val file = filePath
        val riversRef = storageRef.child(
            refStorage + FirebaseAuth.getInstance().currentUser!!.phoneNumber
        )

        val uploadTask = file.let { riversRef.putFile(it) }

        uploadTask.addOnFailureListener {

        }.addOnSuccessListener {
            val urlTask =
                uploadTask.continueWithTask(Continuation<UploadTask.TaskSnapshot, Task<Uri>> { task ->
                    if (!task.isSuccessful) {
                        task.exception?.let {
                            throw it
                        }
                    }
                    return@Continuation riversRef.downloadUrl
                }).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val downloadUri = task.result
                        onSuccess(downloadUri.toString())
                    } else {
                        // Handle failures
                        onSuccess("null")

                    }
                }
        }
    }


    fun uploadAdherent_famille_FromLocalFile(
        filePath: Uri,
        refStorage: String,
        onSuccess: (String) -> Unit
    ) {
        val file = filePath
        val riversRef = storageRef.child(
            refStorage + UUID.randomUUID()
        )

        val uploadTask = file.let { riversRef.putFile(it) }

        uploadTask.addOnFailureListener {

        }.addOnSuccessListener {
            val urlTask =
                uploadTask.continueWithTask(Continuation<UploadTask.TaskSnapshot, Task<Uri>> { task ->
                    if (!task.isSuccessful) {
                        task.exception?.let {
                            throw it
                        }
                    }
                    return@Continuation riversRef.downloadUrl
                }).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val downloadUri = task.result
                        onSuccess(downloadUri.toString())
                    } else {
                        // Handle failures
                        onSuccess("null")

                    }
                }
        }
    }


    fun uploadPDF_FromLocalFile(
        filePath: Uri,
        refStorage: String,
        pdfName: String,
        onSuccess: (String) -> Unit
    ) {
        val file = filePath
        val riversRef = storageRef.child(
            refStorage + FirebaseAuth.getInstance().currentUser?.phoneNumber + pdfName + (UUID.randomUUID().toString().substring(
                0,
                10
            ))
        )

        val uploadTask = file.let { riversRef.putFile(it) }

        uploadTask.addOnFailureListener {

        }.addOnSuccessListener {
            val urlTask =
                uploadTask.continueWithTask(Continuation<UploadTask.TaskSnapshot, Task<Uri>> { task ->
                    if (!task.isSuccessful) {
                        task.exception?.let {
                            throw it
                        }
                    }
                    return@Continuation riversRef.downloadUrl
                }).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val downloadUri = task.result
                        onSuccess(downloadUri.toString())
                    } else {
                        // Handle failures
                        onSuccess("null")

                    }
                }
        }
    }


}