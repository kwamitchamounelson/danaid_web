package com.danaid.danaidmobile.allUi.adherentView.uiFragments.suivreMesServices

import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.danaid.danaidmobile.R

class SuivreMesServicesFragment : Fragment() {

    companion object {
        fun newInstance() = SuivreMesServicesFragment()
    }

    private lateinit var viewModel: SuivreMesServicesViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.suivre_mes_services_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(SuivreMesServicesViewModel::class.java)
        // TODO: Use the ViewModel
    }

}
