package com.danaid.danaidmobile.allUi.authentification.uiFragments.creerCompteMedecin

import androidx.lifecycle.ViewModel

class CreateMedecintAcountViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
