package com.danaid.danaidmobile.allUi.authentification.uiFragments.selectionProfil

import android.graphics.drawable.Drawable
import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager

import com.danaid.danaidmobile.R
import com.danaid.danaidmobile.allUi.authentification.entities.ENUMPROFIL
import com.danaid.danaidmobile.allUi.authentification.uiFragments.selectionProfil.item.ProfilItem
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.Section
import com.xwray.groupie.kotlinandroidextensions.Item
import com.xwray.groupie.kotlinandroidextensions.ViewHolder
import kotlinx.android.synthetic.main.selection_profil_fragment.*

class SelectionProfilFragment : Fragment() {

    companion object {
        fun newInstance() =
            SelectionProfilFragment()
    }

    private lateinit var viewModel: SelectionProfilViewModel
    var profilItems= mutableListOf<Item>()
    private lateinit var itemSectionProfil: Section

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        (activity as AppCompatActivity).supportActionBar!!.apply {
            title = getString(R.string.selectioner_votre_profil)
        }

        return inflater.inflate(R.layout.selection_profil_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(SelectionProfilViewModel::class.java)
        // TODO: Use the ViewModel
        initData()
        id_recycle_view_profil_list.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = GroupAdapter<ViewHolder>().apply {
                itemSectionProfil = Section(profilItems)
                add(itemSectionProfil)
                //setOnItemClickListener(onItemClickDetailOperation)
            }
        }
    }

    private fun initData() {
        val profilList = arrayListOf<ProfilItem>()
        ENUMPROFIL.values().forEach {
            profilList.add(ProfilItem(it.profil))
        }
        profilItems.clear()
        profilItems.addAll(profilList)
    }

}
