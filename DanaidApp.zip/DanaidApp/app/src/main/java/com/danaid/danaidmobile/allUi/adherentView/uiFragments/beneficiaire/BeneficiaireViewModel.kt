package com.danaid.danaidmobile.allUi.adherentView.uiFragments.beneficiaire

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class BeneficiaireViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "Ajout/suppression/ beneficiare"
    }
    val text: LiveData<String> = _text
}