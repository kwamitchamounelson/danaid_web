package com.danaid.danaidmobile.allUi.authentification.entities

import com.danaid.danaidmobile.R

enum class ENUMNIVEAUSERVICES(val niveauDService: NiveauDService) {
    NIVEAUSERVICE1(
        NiveauDService(
            "Niveau1: Accès",
            3500.0,
            "Mois",
            "Famille",
            R.drawable.ic_niveau_service1,
            false
        )
    ),
    NIVEAUSERVICE2(
        NiveauDService(
            "Niveau2: Assist",
            6500.0,
            "Mois",
            "Famille",
            R.drawable.ic_niveau_service2,
            false
        )
    ),
    NIVEAUSERVICE3(
        NiveauDService(
            "Niveau3: Sérénité",
            6500.0,
            "Mois",
            "Famille",
            R.drawable.ic_niveau_service3,
            false
        )
    )
}