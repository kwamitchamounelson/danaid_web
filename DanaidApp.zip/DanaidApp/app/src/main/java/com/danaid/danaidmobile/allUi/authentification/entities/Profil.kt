package com.danaid.danaidmobile.allUi.authentification.entities

class Profil(val name:String,val description:String,val image:Int) {
    constructor():this("","",0)
}