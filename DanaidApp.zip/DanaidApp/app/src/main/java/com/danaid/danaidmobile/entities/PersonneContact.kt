package com.danaid.danaidapp.model.entities

import java.util.*

class PersonneContact(
    phone: Phone,
    fullName: String,
    profil: String,
    emailAdress: String,
    imageUrl: String?,
    val fonction: String,
    val createdDate: Date
)