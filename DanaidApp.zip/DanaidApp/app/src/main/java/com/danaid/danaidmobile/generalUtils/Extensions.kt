package com.danaid.danaidapp.general_util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.ImageView
import androidx.swiperefreshlayout.widget.CircularProgressDrawable
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.danaid.danaidmobile.R
import java.util.*

fun getProgressDrawable(context: Context): CircularProgressDrawable {
    return CircularProgressDrawable(context).apply {
        strokeWidth = 10f
        centerRadius = 50f
        start()
    }
}

fun ImageView.loaImage(uri: String?, progressDrawable: CircularProgressDrawable) {
    val options = RequestOptions()
        .placeholder(progressDrawable)
        .error(R.drawable.ic_circular_user)
    Glide.with(context)
        .setDefaultRequestOptions(options)
        .load(uri)
        .circleCrop()
        .into(this)
}

fun Uri.getName(context: Context): String {
    val returnCursor = context.contentResolver.query(this, null, null, null, null)
    var nameIndex: Int = 0
    try {
        nameIndex = returnCursor!!.getColumnIndex(OpenableColumns.DISPLAY_NAME)
    } catch (e: Exception) {
        val randomName = UUID.randomUUID().toString()
        return randomName.substring(randomName.length-15, randomName.length)+".pdf"
    }

    returnCursor.moveToFirst()
    val fileName = returnCursor.getString(nameIndex)
    returnCursor.close()
    return fileName
}