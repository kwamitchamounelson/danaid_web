package com.danaid.danaidapp.model.entities

import com.google.firebase.firestore.FieldValue

data class Paiement(
    val userPhoneNumber:String,
    val isPaimentValider: Boolean,
    val isViaInscription: Boolean,
    val paiementAmount: Long,
    val userProtectionLevel: Int,
    val paiementDate: FieldValue
)