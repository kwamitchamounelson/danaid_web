package com.danaid.danaidapp.general_util

import android.content.Context
import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.net.Uri
import android.os.Build
import android.util.Log
import java.util.*

const val TAG = "OperationUtils"

const val PICK_PDF_CODE = 3
const val REQUESTrEADiMAGE = 2
const val RC_SELECT_IMAGE = 1
const val REQUESTOPENCAMERA = 4
const val PERMISSION_REQUEST_CODE_PHOTO = 6
const val IMAGE_CAPTURE_CODE = 5

//code de détection de l'opérateur orange à partir d'un numéro de téléphone
fun isOrangeOperator(phoneNumber: String): Boolean {
    var firtsSubSeq = phoneNumber.subSequence(4, 6) as String
    var secondSubSeq = phoneNumber.subSequence(4, 7) as String
    return (firtsSubSeq.toInt() == 69
            || secondSubSeq.toInt() in 655..659)
}

//code de détection de l'opérateur Mtn à partir d'un numéro de téléphone
fun isMTNOoperator(phoneNumber: String): Boolean {
    var firtsSubSeq = phoneNumber.subSequence(4, 6) as String
    var secondSubSeq = phoneNumber.subSequence(4, 7) as String
    return (firtsSubSeq.toInt() == 67
            || (secondSubSeq.toInt() in 650..654) || secondSubSeq.toInt() in 680..689)
}


//ce code permet de convertir un code USSD chiane de caracrtère en URI
fun ussdToCallableUri(ussd: String): Uri {
    Log.d(TAG, "Firts USSD String  $ussd")

    var uriString = ""

    for (c in ussd.toCharArray()) {

        when (c) {
            '#' -> uriString += Uri.encode("#")
            '*' -> uriString += Uri.encode("#")
            else -> uriString += c
        }
    }

    Log.d(TAG, "final USSD String  $uriString")

    return Uri.parse("tel:$uriString")
}

fun Date.toString(format: String, locale: Locale = Locale.getDefault()): String {

    val formatter = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        SimpleDateFormat(format, locale)
    } else {
        TODO("VERSION.SDK_INT < N")
    }
    return formatter.format(this)
}

const val DANAID_MTN_PAIEMENT_PHONE_NUMBER = "(+237) 673 662 062"
const val DANAID_ORANGE_PAIEMENT_PHONE_NUMBER = "696870726"

const val DANAID_TELEPHONE_DEMANDE_ASSISTANCE = "+237673662062"
const val DANAID_EMAIL_DEMANDE_ASSISTANCE = "info@danaid.org"


fun getCurrentDateTime(): Date {
    return Calendar.getInstance().time
}

fun getCurrentdate(): Date {

    val cal = Calendar.getInstance()
    val dayofyear = cal.get(Calendar.DAY_OF_YEAR)
    val year = cal.get(Calendar.YEAR)
    val dayofweek = cal.get(Calendar.DAY_OF_WEEK)
    val dayofmonth = cal.get(Calendar.DAY_OF_MONTH)

    val month = cal.get(Calendar.MONTH)

    return Date(year, month, dayofmonth)
}

fun shareInvitation(title: String, subjet: String, context: Context) {
    val intent = Intent()
    intent.action = Intent.ACTION_SEND
    intent.putExtra(Intent.EXTRA_TEXT, "$title $subjet")
    intent.type = "text/plain"
    context.startActivity(intent)
}

fun isEmailValid(textEmail: CharSequence): Boolean {
    return android.util.Patterns.EMAIL_ADDRESS.matcher(textEmail).matches()
}

val DATE_FORMAT_ = "dd-MMM-yyyy"
fun getStringCurrentDate(): String {
    val dateFormat = java.text.SimpleDateFormat(DATE_FORMAT_)
    dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
    val toDay = Calendar.getInstance().time
    // val endDay = toDay..plusMonths(viewModel.compteurNbreMois)
    return dateFormat.format(toDay)
    // id_date_fin.text = dateFormat.format(endDay)
}

fun convertDateToSpecificStringFormat(date: Date):String{
    val dateFormat = java.text.SimpleDateFormat(DATE_FORMAT_)
    return dateFormat.format(date)
}

fun addMonthOnDate(date: Date, month:Int): Date {
    val cal = Calendar.getInstance()
    cal.time = date
    cal.add(Calendar.MONTH, month)
    return cal.time
}