package com.danaid.danaidapp.model.entities

enum class ADHERENTMAINVIEW {
    MESSERVICES,
    MAFAMILLE,
    MONSTATUS,
    CONTACTS
}