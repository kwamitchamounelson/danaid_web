package com.danaid.danaidapp.model.entities

import java.util.*

data class Adherent(
    var phoneList: ArrayList<Phone>? = ArrayList<Phone>(),
    var fullName: String,
    var profil: String,
    var emailAdress: String,
    var imageUrl: String?,
    var protectionLevel: Int,
    var profession: String,
    var adresse: String,
    var commune: String,
    var statuMatrimonialMarie: Boolean,
    var nombreEnfant: Int?,
    var IsRecptionPaiementMobile: Boolean,
    var dateNaissance: Date,
    //var serverTimestamp: Fieldvarue,
    var createdDate: Date,
    var urlDocOficiel: String,
    var isProfilEnabled: Boolean
) {
    constructor() : this(
        null,
        "",
        "",
        "",
        "",
        0,
        "",
        "",
        "",
        false,
        0,
        true,
        Date(),
        Date(),
        "",
        true
    )
}