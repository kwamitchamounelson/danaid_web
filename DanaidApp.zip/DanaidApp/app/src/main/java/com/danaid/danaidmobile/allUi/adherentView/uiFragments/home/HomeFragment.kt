package com.danaid.danaidmobile.allUi.adherentView.uiFragments.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CircleCrop
import com.danaid.danaidmobile.R
import kotlinx.android.synthetic.main.fragment_home.*

class HomeFragment : Fragment() {

    private lateinit var homeViewModel: HomeViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_home, container, false)
        return root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        homeViewModel = ViewModelProviders.of(this).get(HomeViewModel::class.java)
        //homeViewModel.findCurentAdherentInfos()
        id_adherent_home_profil.setOnClickListener {
            Navigation.findNavController(it)
                .navigate(R.id.action_nav_adherent_home_to_completerMonProfilFragment)
        }

        configureObservers()
    }

    private fun configureObservers() {
        homeViewModel.adherentObserver.observe(this, Observer { curentAdherent ->
            Glide.with(this)
                .load(curentAdherent.imageUrl)
                .placeholder(R.drawable.ic_circular_user)
                .transform(CircleCrop())
                .into(_id_improfil_adherent_homeview)
            _id_tv_name_profil_adherent_homeview.text = curentAdherent.fullName
            _id_tv_phone_profil_adherent_homeview.text = curentAdherent.phoneList?.get(0)!!.number
        })
    }
}