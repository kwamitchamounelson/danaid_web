package com.danaid.danaidmobile.allUi.authentification.entities

data class DetailNiveauService(
    val suivi: String,
    val pourcentageCouverture: Int,
    val plafondAnnuel: String,
    val cotisation: String,
    val paiement: String
) {
    constructor() : this(
        "Medecin de famille",
        70,
        "350 000 fcfa/an",
        "3500 fcfa/mois/famille",
        "Tous les 3 mois"
    )
}