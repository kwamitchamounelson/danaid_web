package com.danaid.danaidmobile.repositories.gestionMedecins

import android.util.Log
import com.danaid.danaidapp.model.entities.Adherent
import com.danaid.danaidapp.model.entities.Doctor
import com.danaid.danaidmobile.repositories.MEDECINS_COLLECTION_REF
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

object FireStoreMedecinsUtils {
    private val TAG = "FireStoreUsersUtils"
    private val firestoreInstance: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    private val curentMedecinRef: DocumentReference
        get() = firestoreInstance.document(
            MEDECINS_COLLECTION_REF + "/${FirebaseAuth.getInstance().currentUser?.phoneNumber
                ?: throw NullPointerException("Phone number is null..")}"
        )

    fun saveMedecinToFireStore(newDoctor: Doctor, onComplete: (isSaved: Boolean) -> Unit) {
        curentMedecinRef.get().addOnSuccessListener { documentSnapshot ->
            // on initialise le medecin la première fois que s'il n'existe pas encore
            if (!documentSnapshot.exists()) {
                curentMedecinRef.set(newDoctor).addOnSuccessListener { onComplete(true) }
            } else {
                // s'il existe déja on ne l'initialise plus
                onComplete(false)
            }
        }
    }

    fun getCurentMedecinFromFiresTore(onSuccess: (Doctor) -> Unit, onError: ()->Unit ) {
        curentMedecinRef.get().addOnSuccessListener {
            onSuccess(it.toObject(Doctor::class.java)!!)
        }.addOnFailureListener {
            onError()
        }
    }

    /**
     * Cette fonction a pour nut de lister les Medecins
     * **/
/*     fun addSearchMedecinsListenerForcreatingGroupe(
         valeurRecherche: String,
         context: Context,
         onListen: (List<Item>) -> Unit
     ): ListenerRegistration {
         return firestoreInstance.collection(ADHERENTS_COLLECTION_REF)
             .addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                 if (firebaseFirestoreException != null) {
                     Log.e("FIRESTORE", "Users listener error?", firebaseFirestoreException)
                     return@addSnapshotListener
                 }

                 val items = mutableListOf<Item>()
                 querySnapshot?.documents?.forEach {
                     if (it["phoneNumber"] != FirebaseAuth.getInstance().currentUser?.phoneNumber) {

                         if (!valeurRecherche.isEmpty()) {
                             if (it["fullName"].toString().toUpperCase().contains(valeurRecherche.toUpperCase())
                                 || it["profil"].toString().toUpperCase().contains(valeurRecherche.toUpperCase())
                                 || it["speciality"].toString().toUpperCase().contains(valeurRecherche.toUpperCase())
                                 || it["nameEtablissement"].toString().toUpperCase().contains(valeurRecherche.toUpperCase())
                             ) {
                                 items.add(SimpleuserItem(it.toObject(Doctor::class.java)!!, context))
                                 Log.d("FIRESTOREUTIL", "NOUVELLE VALEURE AJOUTTEE !!!")
                             }
                         } else {
                             items.add(SimpleuserItem(it.toObject(Doctor::class.java)!!, context))
                         }
                     }
                 }
                 onListen(items)
             }
     }*/

}