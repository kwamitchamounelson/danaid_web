package com.danaid.danaidapp.model.entities

import java.util.*

data class Association(
    val phone: Phone,
    val fullName: String,
    val profil: String,
    val emailAdress: String,
    val imageUrl: String?,
    val protectionLevel: Long,
    val familleNumber: Int,
    val associationAdresse: String,
    val personneContacter: PersonneContact,
    val isAnabled:Boolean,
    val createdDate: Date


)