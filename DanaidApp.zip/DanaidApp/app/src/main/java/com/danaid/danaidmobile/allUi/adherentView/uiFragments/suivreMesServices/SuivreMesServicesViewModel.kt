package com.danaid.danaidmobile.allUi.adherentView.uiFragments.suivreMesServices

import androidx.lifecycle.ViewModel

class SuivreMesServicesViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
