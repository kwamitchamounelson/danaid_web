package com.danaid.danaidmobile.allUi.adherentView.uiFragments.completerMonProfil

import androidx.lifecycle.ViewModel

class CompleterMonProfilViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
