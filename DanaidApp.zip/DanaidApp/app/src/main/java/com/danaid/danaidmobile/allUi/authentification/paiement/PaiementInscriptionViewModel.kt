package com.danaid.danaidmobile.allUi.authentification.paiement

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.danaid.danaidapp.model.entities.Paiement
import com.danaid.danaidmobile.allUi.authentification.entities.NiveauDService
import com.danaid.danaidmobile.repositories.gestionAdherents.FireStoreAdherentUtils
import com.google.firebase.auth.FirebaseAuth

class PaiementInscriptionViewModel : ViewModel() {

    val montantTotalObserver = MutableLiveData<Long>()
    val nombreDeMoisObserver = MutableLiveData<Int>()

    var configPaiementMin = 3500
    var configPaiementMax = 42000
    var configUnit = 3500

    private val fraitInscription: Long = 10000
    var compteurNbreMois: Long = 0
    var montantTotal: Long = 0


    var adherentprotectionLevel = -1
    val adherentPhoneNumer = FirebaseAuth.getInstance().currentUser!!.phoneNumber ?: ""


    val savepaiementEnCour = MutableLiveData<Boolean>()

    fun incrementerNombreDeMois() {
        compteurNbreMois++
        montantTotal = (configPaiementMin * compteurNbreMois) + fraitInscription
        montantTotalObserver.value = montantTotal
        nombreDeMoisObserver.value = compteurNbreMois.toInt()
    }

    fun decrementerNombreMois() {
        compteurNbreMois--
        montantTotal = (configPaiementMin * compteurNbreMois) + fraitInscription
        montantTotalObserver.value = montantTotal
        nombreDeMoisObserver.value = compteurNbreMois.toInt()

    }

    fun initNombreMois(nbMois: Int = 3) {
        for (i in 1..nbMois) {
            incrementerNombreDeMois()
        }
    }

    fun canSavepaiment(): Boolean {
        return adherentprotectionLevel != -1 && adherentPhoneNumer.isNotEmpty() && montantTotal > 0
    }

    fun savePaiement() {

        val paiementTimestamp = com.google.firebase.firestore.FieldValue.serverTimestamp()
        val paiement = Paiement(
            userPhoneNumber = adherentPhoneNumer,
            isPaimentValider = false,
            isViaInscription = true,
            paiementAmount = montantTotal,
            userProtectionLevel = adherentprotectionLevel,
            paiementDate = paiementTimestamp
        )

        savepaiementEnCour.value = true

        FireStoreAdherentUtils.savePaiement(paiement, onComplete = { paiementInstanceId ->

            if (paiementInstanceId.isNotEmpty()) {
                FireStoreAdherentUtils.savePaiementUserPaiementIdToUserReference(
                    paiementInstanceId,
                    onComplete = {
                        savepaiementEnCour.value = false
                    })
            } else {
                savepaiementEnCour.value = false
            }
        })
    }
}
