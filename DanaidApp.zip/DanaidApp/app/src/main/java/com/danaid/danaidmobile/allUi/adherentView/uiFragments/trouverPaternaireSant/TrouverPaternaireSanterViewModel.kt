package com.danaid.danaidmobile.allUi.adherentView.uiFragments.trouverPaternaireSant

import androidx.lifecycle.ViewModel

class TrouverPaternaireSanterViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
