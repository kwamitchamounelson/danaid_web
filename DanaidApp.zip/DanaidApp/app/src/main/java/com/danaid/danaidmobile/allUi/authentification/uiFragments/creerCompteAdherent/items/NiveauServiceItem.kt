package com.danaid.danaidmobile.allUi.authentification.uiFragments.creerCompteAdherent.items

import android.view.View
import com.bumptech.glide.Glide
import com.danaid.danaidmobile.R
import com.danaid.danaidmobile.allUi.authentification.entities.ENUMNIVEAUSERVICES
import com.danaid.danaidmobile.allUi.authentification.entities.NiveauDService
import com.xwray.groupie.kotlinandroidextensions.Item
import com.xwray.groupie.kotlinandroidextensions.ViewHolder
import kotlinx.android.synthetic.main.row_item_niveau_service.view.*

class NiveauServiceItem(val niveauService: NiveauDService) : Item() {
    override fun bind(viewHolder: ViewHolder, position: Int) {
        viewHolder.itemView.id_tv_niveau_service_nom.text = niveauService.nomNiveau
        val details =
            "${niveauService.montant}/${niveauService.periode}/${niveauService.couverture}"
        viewHolder.itemView.id_tv_niveau_service_detail.text = details

        Glide.with(viewHolder.itemView)
            .load(niveauService.icon)
            .into(viewHolder.itemView.id_imv_niveau_service)

        if (niveauService.isSelected) {
            viewHolder.itemView.id_imv_niveau_service_is_selected.visibility = View.VISIBLE
        }
    }

    override fun getLayout() = R.layout.row_item_niveau_service
}