package com.danaid.danaidapp.model.entities.repositories.remote

import android.util.Log
import com.danaid.danaidapp.model.entities.User
import com.danaid.danaidmobile.repositories.USERS_COLLECTION_REF
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore

object FireStoreUsersutils {
    private val TAG = "FireStoreUsersUtils"
    private val firestoreInstance: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    private val curentUserDocRef: DocumentReference
        get() = firestoreInstance.document(
            USERS_COLLECTION_REF.plus(
                "/${FirebaseAuth.getInstance().currentUser?.phoneNumber
                    ?: throw NullPointerException("Phone number is null..")}"
            )
        )

    fun saveUserToFireStore(newUser: User, onComplete: (isSaved: Boolean) -> Unit) {
        curentUserDocRef.get().addOnSuccessListener { documentSnapshot ->
            // on initialise l'utilisateur la première fois que s'il n'existe pas encore
            if (!documentSnapshot.exists()) {
                curentUserDocRef.set(newUser).addOnSuccessListener { onComplete(true) }
            } else {
                // s'il existe déja on ne l'initialise plus
                onComplete(false)
            }
        }.addOnFailureListener {
            Log.d(TAG, it.message)
            onComplete(false)
        }
    }


    fun upDateuser(user: User, onSucess: () -> Unit, onError: () -> Unit) {
        val userFieldMap = mutableMapOf<String, Any>()
        userFieldMap["createdDate"] = user.createdDate
        userFieldMap["emailAdress"] = user.emailAdress ?: ""
        userFieldMap["enabled"] = user.isEnabled
        userFieldMap["fullName"] = user.fullName
        userFieldMap["imageUrl"] = user.imageUrl ?: ""
        userFieldMap["phoneList"] = user.phoneList
        userFieldMap["profil"] = user.profil
        userFieldMap["urlCNI"] = user.urlCNI

        curentUserDocRef.update(userFieldMap).addOnSuccessListener {
            Log.d(TAG, "User has updated succesfully")
            onSucess()
        }
            .addOnFailureListener {
                Log.d(TAG, "Error to updated user" + it.cause)

                onError()
            }

    }

    fun getCurentUserFromFiresTore(onSucess: (User) -> Unit, onError: () -> Unit) {
        curentUserDocRef.get().addOnSuccessListener {
            try {
                onSucess(it.toObject(User::class.java)!!)
            } catch (ex: Exception) {
                Log.d(TAG, "Error: utilisateur inexistant " + ex.cause)
                onError()
            }
        }.addOnFailureListener {
            onError()

        }


    }

}