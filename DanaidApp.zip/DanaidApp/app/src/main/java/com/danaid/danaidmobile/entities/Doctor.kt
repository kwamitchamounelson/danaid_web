package com.danaid.danaidapp.model.entities

import java.util.*

data class Doctor(
    var phoneList: ArrayList<Phone>? = ArrayList<Phone>(),
    var fullName: String,
    var profil: String,
    var emailAdress: String,
    var imageUrl: String?,
    var speciality: String,
    var matricule: String,
    var nameEtablissement: String,
    var Sector: String,
    var etablisementAdress: String,
    var commune: String,
    var urlCNI:String,
    var isAnabled:Boolean,
    var createdDate: Date


    ) {
    constructor() :
            this(null, "", "", "", "", "", "", "", "", "", "","", false, Date())

}